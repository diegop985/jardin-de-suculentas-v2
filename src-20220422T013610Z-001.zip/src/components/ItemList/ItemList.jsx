
function ItemList(propsItemList) {
    return (
        <div className="itemList">
            {propsItemList.children}
        </div>
    );
}

export default ItemList;